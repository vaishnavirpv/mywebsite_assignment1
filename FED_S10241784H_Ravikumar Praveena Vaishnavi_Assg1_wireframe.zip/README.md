# mywebsite_assignment1
This is the FED assignment website. 
